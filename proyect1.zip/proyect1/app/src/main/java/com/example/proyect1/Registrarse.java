package com.example.proyect1;

import androidx.annotation.AttrRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class Registrarse extends actividad1 {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //actividad que sirve para registrar a un usuario
        super.onCreate(savedInstanceState);
        cambiarIdioma(idioma);
        setContentView(R.layout.activity_registrarse);
        //se cogen los datos de los EditText
        EditText nombre = (EditText) findViewById(R.id.RegistrarseNombre);
        EditText email = (EditText) findViewById(R.id.RegistrarseEmail);
        EditText contra1 = (EditText) findViewById(R.id.RegistrarseContraseña1);
        EditText contra2 = (EditText) findViewById(R.id.RegistrarseContraseña2);
        //inicializar la BD
        miBD GestorDB = new miBD (this, "NombreBD", null, 1);
        SQLiteDatabase bd = GestorDB.getWritableDatabase();

        //coger el boton Registrarse
        Button btnRegistrare=(Button) findViewById(R.id.BotonConfirmarRegistro);
        btnRegistrare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //se pasan a String los datos de los EditText
                String n1 =nombre.getText().toString();
                String e1 =email.getText().toString();
                String c1 =contra1.getText().toString();
                String c2 =contra2.getText().toString();
                //Al registrarse se pone una imagen básica para el nuevo usuario, pero despues en cambiar perfil es posible cambiar la imagen
                String urlImagenBasica= "https://www.ver.bo/wp-content/uploads/2019/01/4b463f287cd814216b7e7b2e52e82687.png_1805022883.png";

                String[] campos = new String[] {"Codigo", "Nombre"};

                ContentValues nuevo = new ContentValues();
                nuevo.put("Nombre",n1);
                nuevo.put("email",e1);
                nuevo.put("password",c1);
                nuevo.put("imagen",urlImagenBasica);
                //query para mirar si no existe el usuario con ese email
                String[] argumentos = new String[] {e1};
                Cursor c = bd.query("Usuarios",campos,"email==?",argumentos,null,null,null);

                int cod;
                if(c1.equals(c2)){
                    //si las contraseñas son iguales
                    if(!c.moveToNext()) {
                        //si el usuario no existe
                        //insertar en la tabla Usuarios
                        bd.insert("Usuarios", null, nuevo);
                        //query para coger el Codigo del usuario que se acaba de crear
                        Cursor cursor2 = bd.query("Usuarios",campos,"email==?",argumentos,null,null,null);
                        //pasar a la actividad PaginaPrincipal
                        Intent intent = new Intent (Registrarse.this, PaginaPrincipal.class);
                        if (cursor2.moveToNext()){

                            cod=cursor2.getInt(0);
                            intent.putExtra("codigoUsuario",Integer.toString(cod) );//meter el codigo del usuario en el intent
                        }
                        //crear una notificación para notificar que se a creado con exito el usuario
                        NotificationManager elManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
                        NotificationCompat.Builder elBuilder = new NotificationCompat.Builder(Registrarse.this,"idCanal");
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            NotificationChannel elCanal = new NotificationChannel("IdCanal", getResources().getString(R.string.Registro),NotificationManager.IMPORTANCE_DEFAULT);
                            elManager.createNotificationChannel(elCanal);
                            elCanal.setDescription(getResources().getString(R.string.cuentaCreada));
                            elCanal.enableLights(true);
                            elCanal.setLightColor(Color.RED);
                            elCanal.setVibrationPattern(new long[]{0, 1000, 500, 1000});
                            elCanal.enableVibration(true);
                        }
                        elBuilder.setSmallIcon(android.R.drawable.stat_sys_warning)
                                .setContentTitle("Mensaje de Alerta")
                                .setContentText(getResources().getString(R.string.cuentaCreada))
                                .setSubText(getResources().getString(R.string.Registro))
                                .setVibrate(new long[]{0, 1000, 500, 1000})
                                .setAutoCancel(true);


                        elManager.notify(1, elBuilder.build());

                        c.close();          //cerrar la base de datos
                        cursor2.close();
                        bd.close();
                        intent.putExtra("idioma",idioma); //meter el idioma en el intent
                        startActivity(intent);
                        finish();
                        //cambiar a pantalla principal

                        //crear un Toast que diga que la cuentra ha sido creada
                        Toast.makeText(Registrarse.this, getResources().getString(R.string.RegistrarseBien), Toast.LENGTH_SHORT).show();

                    }
                    else{
                        //crear un toast que diga que el usuario ya existe
                        Toast.makeText(Registrarse.this, getResources().getString(R.string.UsuarioExiste), Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    //hacerun toast pa ver k no se hahecho correctamente
                    Toast.makeText(Registrarse.this,getResources().getString(R.string.RegistrarseMal),Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    @Override
    public void onBackPressed() {
        //función que al pulsa la flecha para atras vaya a MainActivity
        Intent intent = new Intent (Registrarse.this, MainActivity.class);
        intent.putExtra("idioma",idioma);
        startActivity(intent);
        finish();
    }
}
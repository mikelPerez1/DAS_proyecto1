package com.example.proyect1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends actividad1 {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        cambiarIdioma(idioma); //cambiar el idioma al elegido o en caso de no haber modificado el idioma todavia, usar el que estaba por defecto
        setContentView(R.layout.activity_main);









        }



    public void LogIn(View v){ // función que al pulsar el botonLogin te lleve a la pantalla Login
        Intent intent = new Intent (MainActivity.this, LogIn.class);
        intent.putExtra("idioma",idioma);
        startActivity(intent);
        finish();
    }


    public void opciones(View v){ //función que al pulsar el boton Opciones te lleve a la pantalla de opciones
        Intent intent = new Intent (MainActivity.this, Opciones.class);
        intent.putExtra("idioma",idioma);
        startActivity(intent);
        finish();

    }

    public void cambiarARegistrarse(View v){//función que al pulsar el boton Registrarse te lleve a la pantalla de Registrarse
        Intent intent = new Intent (MainActivity.this, Registrarse.class);
        intent.putExtra("idioma",idioma);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() { //función que al darle a la flechita para atras del móvil te salga un dialog preguntando si quieres salir de la aplicación.


        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage(getResources().getString(R.string.SalirAplicacion)); //mensaje del dialog
        builder.setCancelable(false);

        builder.setNegativeButton(getResources().getString(R.string.Cancelar), new DialogInterface.OnClickListener() {  // boton Cancelar que al pulsarlo solo quita el dialog
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.setPositiveButton(getResources().getString(R.string.Aceptar), new DialogInterface.OnClickListener() { //boton Aceptar que al pulsarlo sale de la aplicación
            @Override
            public void onClick(DialogInterface dialog, int which) {

                finish();
            }
        });


        AlertDialog dialog  = builder.create();
        dialog.show();
    }


}
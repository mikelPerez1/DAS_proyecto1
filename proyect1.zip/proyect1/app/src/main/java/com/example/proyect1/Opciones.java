package com.example.proyect1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.DialogFragment;
import androidx.preference.PreferenceManager;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.os.LocaleList;
import android.text.Layout;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.Toast;

import com.google.android.datatransport.Event;

import java.util.ArrayList;
import java.util.Locale;


public class Opciones extends actividad1 {

    String msg ="";
    final String[] idioma = new String[1];
    final CharSequence[] opciones = {"Español", "Ingles"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //la Actividad Opciones sirve para cambiar el idioma de la aplicación o poner en modo nocturno la aplicación

        super.onCreate(savedInstanceState);
        if(savedInstanceState!=null){
        idioma[0]=savedInstanceState.getString("idioma");}//si savdInstanceState es distinto de null se le pone a idioma[0] el parametro que se ha guardado en la función onSaveInstanceState(Bundle outState)
        if(idioma[0]==null){ //si idioma[0] es null se le mete el valor del idioma que estaba por defecto
            idioma[0]=String.valueOf(Locale.getDefault());
        }
        //el idioma que estaba por defecto puede ser en_US, asi que se pasa a en para que el codigo como lo tengo hecho lo entienda
        if(idioma[0].equals("en_US")){
            idioma[0]="en";
        }
        cambiarIdioma(idioma[0]); // se pone el idioma elegido
        setContentView(R.layout.activity_opciones);

        Switch switchNocturno = (Switch) findViewById(R.id.switchNocturno); //se coge el switch para cambiar al modo nocturno

        Button btn = (Button)findViewById(R.id.botonIdioma);//se coge el boton que al presionarlo muestre los idiomas disponibles
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //se crea un alertDialog
                AlertDialog.Builder builder = new AlertDialog.Builder(Opciones.this);
                //en este alert dialog salen las opciones de idioma , pudiendo elegir 1 elemento a la vez
                builder.setTitle(getResources().getString(R.string.elegirIdioma))
                        .setSingleChoiceItems(opciones, -1, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                if (i==0){// si se elige el elemento 0 (en este caso español) a idioma[0] se le pondrá el valor "es"
                                    idioma[0] ="es";
                                }
                                else{//por otro lado si elige el ingles o no elige se le pondra el ingles
                                    idioma[0] ="en";
                                }

                            }
                        })     .setCancelable(false)
                        .setPositiveButton(getResources().getString(R.string.Aceptar), new DialogInterface.OnClickListener() {
                            //un boton que al aceptar se cambia el idioma y se refresca la actividad para aparecer con el idioma elegido
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                cambiarIdioma(idioma[0]);
                                recreate();
                            }
                        })
                        .setNegativeButton(getResources().getString(R.string.Cancelar), new DialogInterface.OnClickListener() {
                           // un boton que cancela el dialog
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(Opciones.this,"No Option Selected",Toast.LENGTH_SHORT).show();
                            }
                        });
                //Crear el dialogBox
                AlertDialog dialog  = builder.create();
                dialog.show();
            }
        });


        switchNocturno.setOnClickListener(new View.OnClickListener()
        {
            //un switch que sirve para pasar del modo claro al nocturno y viceversa
            @Override
            public void onClick(View view) {
                if (switchNocturno.isChecked()) //checking if  switch is checked
                {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                }
            }

        });



    }


    public void irPantallaPrincipal(View v){
        //un intent para ir a MainActivity
        Intent intent = new Intent (Opciones.this, MainActivity.class);
        intent.putExtra("idioma",idioma[0]);
        startActivity(intent);
        finish();

    }

    @Override
    public void onBackPressed() {
        // una función que al pulsar la flecha para atras del móvil vuelva a la MainActivity
        Intent intent = new Intent (Opciones.this, MainActivity.class);
        intent.putExtra("idioma",idioma[0]);
        startActivity(intent);
        finish();
    }


    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("idioma",idioma[0]);//para guardar el idioma al girar la pantalla

    }
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        idioma[0]=savedInstanceState.getString("idioma");//para recuperar el idioma al girar la pantalla


    }
}
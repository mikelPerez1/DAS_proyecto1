package com.example.proyect1;


import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class AdaptadorListView extends BaseAdapter {
    //Adaptador del listview que muestra los amigos de un usuario (una foto y el nombre)


    private Context contexto;
    private LayoutInflater inflater;
    private ArrayList<String> datos;
    private ArrayList<String> imagenes;
    private double[] puntuaciones;
    public AdaptadorListView(Context pcontext, ArrayList<String> pdatos, ArrayList<String> pimagenes)
        {
        contexto=pcontext;
        datos=pdatos;
        imagenes=pimagenes;

        inflater=(LayoutInflater)contexto.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

    @Override
    public int getCount() {
        return datos.size();
    }

    @Override
    public Object getItem(int i) {
        return datos.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view=inflater.inflate(R.layout.listview,null);
        TextView nombre= (TextView) view.findViewById(R.id.etiqueta);
        ImageView img=(ImageView) view.findViewById(R.id.imagen);

        //se le pone el nombre del amigo en el textView dado
        nombre.setText(datos.get(i));

        //se descarga la imagen de la url dada en el ImageView dado
        new DownloadImageTask((ImageView) view.findViewById(R.id.imagen)).execute(imagenes.get(i));


        return view;
    }
}
package com.example.proyect1;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import java.util.ArrayList;

public class Amigos extends actividad1 {
    String valor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //actividad que utiliza el listview personalizado para mostrar los amigos del usuario

        super.onCreate(savedInstanceState);
        cambiarIdioma(idioma);//cambia el idioma al que se ha elegido previamente en las opciones de la aplicación
        setContentView(R.layout.activity_contactos);

        Bundle extras = getIntent().getExtras();
        String codigo="";

        if (extras != null) {
            codigo= extras.getString("codigoUsuario");//se obtiene el Código del usuario
            valor=codigo;

        }

        miBD GestorDB = new miBD (this, "NombreBD", null, 1);
        SQLiteDatabase bd = GestorDB.getWritableDatabase();




        ArrayList<String> nombres = new ArrayList<String>();//arrayList de los nombres
        ArrayList<String> imagenes= new ArrayList<String>();//arraylist de las url de las imagenes

        String[] argumentos = new String[]{codigo};
        String[] campos = new String[] {"Nombre","imagen"};
        //Query que selecciona el nombre y la imagen de los usuarios que estén añadidos en la lista de amigos del usuario,
        //para eso busca en la tabla Seguidores las filas que su CodigoP sea el mismo del usuario actual, Coge el CodigoS
        //asociado y de ahí saca el nombre y la imagen
        Cursor c = bd.query("Usuarios inner join Seguidores",campos,"Seguidores.CodigoS==Usuarios.Codigo and Seguidores.CodigoP==?",argumentos,null,null,null);


        while(c.moveToNext()){ //mientras haya encontrado
            nombres.add(c.getString(0)); //coge el nombre
            imagenes.add(c.getString(1)); //coge la url de la imagen

        }




        ListView contactos=(ListView) findViewById(R.id.listaContactos); //se coge el listview
        //se crea el adaptador del Listview pasandole los arraylist de los nombres e imagenes
        AdaptadorListView eladap= new AdaptadorListView(getApplicationContext(),nombres,imagenes);
        //se enlaza el listview con el adaptador
        contactos.setAdapter(eladap);


    }
    @Override
    public void onBackPressed() {
        //función que cuando se presone la flecha para atras del móvil vaya a PaginaPrincipal
        Intent intent = new Intent (Amigos.this, PaginaPrincipal.class);
        intent.putExtra("codigoUsuario",valor );
        intent.putExtra("idioma",idioma);
        startActivity(intent);
        finish();
    }
}
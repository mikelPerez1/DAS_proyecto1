package com.example.proyect1;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

public class PaginaPrincipal extends actividad1 {
    String valor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Actividad Principal que sale al logearse
        super.onCreate(savedInstanceState);
        cambiarIdioma(idioma);
        setContentView(R.layout.activity_pagina_principal);
        //inicializar la BD
        miBD GestorDB = new miBD (this, "NombreBD", null, 1);
        SQLiteDatabase bd = GestorDB.getWritableDatabase();
        //Conseguir el Codigo del Usuario que se a pasado con el Intent
        Bundle extras = getIntent().getExtras();
        String codigo="";

        if (extras != null) {
            codigo= extras.getString("codigoUsuario");
            valor=codigo;

        }
        //query para obtener la url de la imagen del usuario
        String[] argumentos = new String[]{codigo};
        String[] campos = new String[] {"imagen"};
        String url="";
        Cursor c = bd.query("Usuarios",campos,"Codigo==?",argumentos,null,null,null);

        if(c.moveToNext()){
            //mostrar  la imagen en la pantalla
            url =c.getString(0);
            new DownloadImageTask((ImageView) findViewById(R.id.imageView)).execute(url); //coge la imagen de la url dada
        }
        c.close();
        bd.close();



    }

    public void cambiarAAmigos(View v){
        //función que pasa a la actividad Amigos
        Intent intent = new Intent (PaginaPrincipal.this, Amigos.class);
        intent.putExtra("codigoUsuario", valor);
        intent.putExtra("idioma",idioma);
        startActivity(intent);
        finish();

    }


    public void cambiarAAñadirAmigos(View v){
        //función que cambia a la actividad anadirAmigos
        Intent intent = new Intent (PaginaPrincipal.this, anadirAmigo.class);
        intent.putExtra("codigoUsuario", valor);
        intent.putExtra("idioma",idioma);
        startActivity(intent);
        finish();

    }

    public void cambiarPerfil(View v){
        //función que cambia a la actividad CambiarPerfil
        Intent intent = new Intent (PaginaPrincipal.this, CambiarPerfil.class);
        intent.putExtra("codigoUsuario", valor);
        intent.putExtra("idioma",idioma);
        startActivity(intent);
        finish();
    }
    @Override
    public void onBackPressed() {
        //al pulsar la flecha para atras del móvil, aparece un AlertDialog que pregunta si quieres salir de la aplicación.
        AlertDialog.Builder builder = new AlertDialog.Builder(PaginaPrincipal.this);
        builder.setMessage(getResources().getString(R.string.SalirAplicacion));
        builder.setCancelable(false);

        builder.setNegativeButton(getResources().getString(R.string.Cancelar), new DialogInterface.OnClickListener() {
            //el boton de cancelar cancela el dialog
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.setPositiveButton(getResources().getString(R.string.Aceptar), new DialogInterface.OnClickListener() {
            //el boton de aceptar cierra la aplicación
            @Override
            public void onClick(DialogInterface dialog, int which) {

                finish();
            }
        });


        AlertDialog dialog  = builder.create();
        dialog.show();
    }

    public void logout(View v){
        //función para deslogearte e ir a la actividad MainActivity
        Intent intent = new Intent (PaginaPrincipal.this, MainActivity.class);
        intent.putExtra("idioma",idioma);
        startActivity(intent);
        finish();

    }

}
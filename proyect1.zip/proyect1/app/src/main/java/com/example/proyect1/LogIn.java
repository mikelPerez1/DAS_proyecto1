package com.example.proyect1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LogIn extends actividad1 {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Actividad que sirve para logearse en la aplicación
        super.onCreate(savedInstanceState);
        cambiarIdioma(idioma); //función para poner el idioma elegido
        setContentView(R.layout.activity_log_in);


        //inicializar la bd
        miBD GestorDB = new miBD (this, "NombreBD", null, 1);
        SQLiteDatabase bd = GestorDB.getWritableDatabase();
        //coger el boton Login
        Button btnLogin=(Button) findViewById(R.id.botonAcceder);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //obtener los datos de email y la contraseña de los editText y pasarlos a String
                EditText email = (EditText) findViewById(R.id.loginEmail);
                EditText contra= (EditText) findViewById(R.id.loginContraseña);
                String e1 =email.getText().toString();
                String c1 =contra.getText().toString();

                //Hacer la query que que devuelva el Codigo, email y password del usuario si existe
                String[] campos = new String[] {"Codigo", "email","password"};
                String[] argumentos = new String[] {e1};
                Cursor c = bd.query("Usuarios",campos,"email==?",argumentos,null,null,null);
                if (c.moveToNext()){
                    //si existe obtener la contraseña, el email y el codigo
                    String contraseña=c.getString(2);
                    String mail=c.getString(1);

                    String cod=Integer.toString(c.getInt(0));
                    // mirar si las contraseñas son iguales y el email también
                    if(c1.equals(contraseña) && e1.equals(mail)){
                        //pasar a la PaginaPrincipal de la aplicación habiendose logeado el usuario
                        Intent intent = new Intent (LogIn.this, PaginaPrincipal.class);
                        intent.putExtra("codigoUsuario",cod );
                        intent.putExtra("idioma",idioma);
                        c.close();
                        bd.close();//cerrar la bd
                        startActivity(intent);
                        finish();

                    }
                    else { // si no es correcta la contraseña mostrar un Toast
                        Toast.makeText(LogIn.this,getResources().getString(R.string.ContraseñaMal),Toast.LENGTH_SHORT).show();
                    }
                }
                else{//si no existe el usuario mostrar un Toast
                    Toast.makeText(LogIn.this,getResources().getString(R.string.UsuarioNoExiste),Toast.LENGTH_SHORT).show();

                }
            }
        });
}

    @Override
    public void onBackPressed() {
        //al pulsar la flecha para atras del móvil volver a la actividad MainActivity
        Intent intent = new Intent (LogIn.this, MainActivity.class);
        intent.putExtra("idioma",idioma);
        startActivity(intent);
        finish();
    }

}
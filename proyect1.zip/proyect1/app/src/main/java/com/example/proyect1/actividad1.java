package com.example.proyect1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;

import java.util.Locale;

public class actividad1 extends AppCompatActivity { //actividad de la que extiendes las otras clases para tener los métodos de esta
    String idioma="en";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle extras = getIntent().getExtras();


        if (extras != null) {
            idioma= extras.getString("idioma"); //obtener el idioma que se pasa al hacer un intent
        }

        setContentView(R.layout.activity_actividad1);



    }
    public void cambiarIdioma(String idioma1){ // función para cambiar el lenguaje de la aplicación
        Locale nuevaloc = new Locale(idioma1);
        Locale.setDefault(nuevaloc);

        Configuration configuration =getBaseContext().getResources().getConfiguration();
        configuration.setLocale(nuevaloc);
        configuration.setLayoutDirection(nuevaloc);
        Context c =getBaseContext().createConfigurationContext(configuration);
        getBaseContext().getResources().updateConfiguration(configuration, c.getResources().getDisplayMetrics());

    }

}
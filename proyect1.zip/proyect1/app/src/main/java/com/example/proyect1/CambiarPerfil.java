package com.example.proyect1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CambiarPerfil extends actividad1 {
    String valor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //Actividad que sirve para cambiar el nombre y la imagen del usuario
        super.onCreate(savedInstanceState);
        cambiarIdioma(idioma); //se pone el idioma elegido
        setContentView(R.layout.activity_cambiar_perfil);
         //se obtiene el codigo del usuario
        Bundle extras = getIntent().getExtras();
        String codigo="";

        if (extras != null) {
            codigo= extras.getString("codigoUsuario");
            Log.d("cod",codigo);
            valor=codigo;

        }

        //se inicia la Base de datos
        miBD GestorDB = new miBD(this, "NombreBD", null, 1);
        SQLiteDatabase bd = GestorDB.getWritableDatabase();

        //se coge el boton de aceptar
        Button btnAceptar = (Button) findViewById(R.id.botonCambiarPerfilAceptar);
        btnAceptar.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                //se obtienen el nombre y la url de la imagen nueva de los EditText y se pasan a String
                EditText nombre = (EditText) findViewById(R.id.perfilNombre);
                EditText imagen= (EditText) findViewById(R.id.perfilImagen);
                String n1 =nombre.getText().toString();
                String i1 =imagen.getText().toString();
                //se añade como argumento el Codigo de usuario para hacer la query
                String[] argumentos = new String[] {valor};
                //se añaden los valores que se han obtenido antes de los EditText y se hace el Update
                ContentValues nuevo = new ContentValues();
                nuevo.put("Nombre",n1);
                nuevo.put("imagen",i1);
                bd.update("Usuarios",nuevo, "Codigo==?",argumentos);

                bd.close();//se cierra la bd
                onBackPressed();// se va a la pagina principal

            }
        });

        Button btnCancelar = (Button) findViewById(R.id.botonPerfilCancelar);//se coge el boton de cancelar
        btnCancelar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                //si se pulsa se cierra la bd y se vuelve a la PaginaPrincipal
                bd.close();
                onBackPressed();
            }
        });
    }
    @Override
    public void onBackPressed() {
        //se vuelve a la pagina principal al pulsar la flecha para atras del móvil
        Intent intent = new Intent (CambiarPerfil.this, PaginaPrincipal.class);
        intent.putExtra("codigoUsuario",valor );
        intent.putExtra("idioma",idioma);
        startActivity(intent);
        finish();
    }
}
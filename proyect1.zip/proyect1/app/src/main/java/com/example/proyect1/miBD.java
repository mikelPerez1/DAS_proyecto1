package com.example.proyect1;

import static java.sql.Types.VARCHAR;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class miBD extends SQLiteOpenHelper {
    //La clase que sirve como Base de datos Local
    public miBD(@Nullable Context context, @Nullable String name,
                @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //las tablas que tiene la base de datos
        //la primera es la tabla Usuarios que tiene los campos Codigo,Nombre,email,contraseña e imagen
        //la segunda tabla es la de Seguidores/amigos, esta tabla consiste de 2 campos, CodigoP  y CodigoS, ambos son codigos de usuarios para saber que Usuarios tiene en su lista un Usuario
        sqLiteDatabase.execSQL("CREATE TABLE Usuarios ('Codigo' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, 'Nombre' VARCHAR(255),'email' VARCHAR(255),'password' VARCHAR (20),'imagen' VARCHAR(255) )");
        sqLiteDatabase.execSQL("CREATE TABLE Seguidores ('CodigoP' INTEGER , 'CodigoS',PRIMARY KEY ('CodigoP','CodigoS'),FOREIGN KEY ('CodigoS') References Usuarios('Codigo'), FOREIGN KEY ('CodigoP') References Usuarios('Codigo') )");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
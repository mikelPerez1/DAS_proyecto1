package com.example.proyect1;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class anadirAmigo extends actividad1 {
    String valor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //Clase que se encarga de añadir amigos a la tabla Seguidores de la base de datos
        super.onCreate(savedInstanceState);
        cambiarIdioma(idioma); //cambia el idioma al idioma seleccionado anteriormente en las opciones de la aplicación (o en caso de no haberlo cambiado, dejarlo en ingles)
        setContentView(R.layout.activity_anadir_contacto);

        // se obtiene el Codigo del usuario pasado con el intent
        Bundle extras = getIntent().getExtras();
        String codigo = "";

        if (extras != null) {
            codigo = extras.getString("codigoUsuario");
            valor = codigo;

        }
        //se inicializa la BD
        miBD GestorDB = new miBD(this, "NombreBD", null, 1);
        SQLiteDatabase bd = GestorDB.getWritableDatabase();
        //se coge el boton que se usa para añadir a un amigo
        Button btn = (Button) findViewById(R.id.botonAñadir);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //se obtiene lo que esta puesto en el EditText y se pasa a String
                EditText email = (EditText) findViewById(R.id.emailAñadir);
                String e1 = email.getText().toString();


                String[] campos = new String[]{"Codigo","Nombre"};//los campos que se van a obtener de la query
                String[] argumentos = new String[]{e1};// los argumentos para la query
                //esta query mira si el email introducido para añadir al amigo existe o no
                Cursor c = bd.query("Usuarios", campos, "email==?", argumentos, null, null, null);

                if (c.moveToNext()) { //en caso de existir
                    String cod2 = Integer.toString(c.getInt(0)); //se obtiene el codigo del amigo
                    String nombre=c.getString(1); // se obtiene e nombre del amigo
                    // se hace otra query para ver si ese amigo ya esta añadido en tu lista de amigos
                    String[] campos2 = new String[]{"CodigoP"};
                    String[] argumentos2 = new String[]{valor,cod2};
                    Cursor c2 = bd.query("Seguidores", campos2, "CodigoP==? and CodigoS==?", argumentos2, null, null, null);
                    if(c2.moveToNext()){ // en caso de que ya esté añadido, saldra un toast diciendotelo
                        Toast.makeText(anadirAmigo.this, getResources().getString(R.string.usuarioAñadidoYa), Toast.LENGTH_SHORT).show();
                    }else {
                        //en caso de que no esté añadido
                        if(!valor.equals(cod2)) { //se mira si no sea el mismo usuario para que no te puedas añadir a ti mismo
                            //se inserta en la base de datos en la tabla Seguidores los codigos del Usuario y del Amigo, se muestra un mensaje por Toast y se vuelve a la PaginaPrincipal
                            ContentValues nuevo = new ContentValues();
                            nuevo.put("CodigoP", valor);
                            nuevo.put("CodigoS", cod2);
                            bd.insert("Seguidores", null, nuevo);
                            Toast.makeText(anadirAmigo.this, getResources().getString(R.string.usuarioAñadido), Toast.LENGTH_SHORT).show();
                            bd.close();
                            onBackPressed();
                            }
                    }
                    c2.close();
                }
                else{
                    //si el usuario no existe saldrá un mensaje
                    Toast.makeText(anadirAmigo.this, getResources().getString(R.string.UsuarioNoExiste), Toast.LENGTH_SHORT).show();
                }
                c.close();

            }
        });
    }

    @Override
    public void onBackPressed() {
        //función que al presionar la flecha para atras del móvil vuelve a la pagina principal

        Intent intent = new Intent (anadirAmigo.this, PaginaPrincipal.class);
        intent.putExtra("codigoUsuario",valor );
        intent.putExtra("idioma",idioma);
        startActivity(intent);
        finish();
    }
}